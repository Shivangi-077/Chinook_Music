--  *** Chinook Project *** --
 
 --  ** OBJECTIVE QUESTIONS **  --
 
 -- 1.Are there any tables with duplicate or missing null values? If so, how would you handle them?
 
-- Checking duplicates in Album ---

SELECT album_id, COUNT(album_id) AS count FROM album GROUP BY album_id HAVING count > 1;
SELECT title, COUNT(title) AS count FROM album GROUP BY title HAVING count > 1;
SELECT artist_id, COUNT(artist_id) AS count FROM album GROUP BY artist_id HAVING count > 1;
select * from album;


-- Checking duplicates in Artist ---

select artist_id, COUNT(artist_id) AS count FROM artist GROUP BY artist_id HAVING count > 1;
SELECT name, COUNT(name) AS count FROM artist GROUP BY name HAVING count > 1;
select * from artist;

-- Checking duplicates in customer ---

SELECT COUNT(*) AS total_rows, COUNT(DISTINCT customer_id) AS distinct_rows FROM customer;
SELECT COUNT(*) AS total_rows, COUNT(DISTINCT first_name) AS distinct_rows FROM customer;
SELECT COUNT(*) AS total_rows, COUNT(DISTINCT last_name) AS distinct_rows FROM customer;
SELECT COUNT(*) AS total_rows, COUNT(DISTINCT company) AS distinct_rows FROM customer;
SELECT COUNT(*) AS total_rows, COUNT(DISTINCT address) AS distinct_rows FROM customer;
select * from customer;

-- Checking duplicates in employee ---

SELECT employee_id, COUNT(employee_id) AS duplicate_count FROM employee GROUP BY employee_id HAVING COUNT(employee_id) > 1;
select * from employee;

-- Checking duplicates in genre ---

SELECT name, COUNT(*) AS duplicate_count FROM genre GROUP BY name HAVING COUNT(*) > 1;
select * from genre;

-- Checking duplicates in invoice ---

-- Check for duplicate invoice_id
SELECT invoice_id, COUNT(*) AS count
FROM invoice
GROUP BY invoice_id
HAVING COUNT(*) > 1;

-- Check for duplicate customer_id
SELECT customer_id, COUNT(*) AS count
FROM invoice
GROUP BY customer_id
HAVING COUNT(*) > 1;

-- Check for duplicate invoice_date
SELECT invoice_date, COUNT(*) AS count
FROM invoice
GROUP BY invoice_date
HAVING COUNT(*) > 1;

-- Check for duplicate total
SELECT total, COUNT(*) AS count
FROM invoice
GROUP BY total
HAVING COUNT(*) > 1;

-- Checking duplicates in invoice-line ---
-- Check for duplicate invoice_line_id
SELECT invoice_line_id, COUNT(*) AS count
FROM invoice_line
GROUP BY invoice_line_id
HAVING COUNT(*) > 1;

-- Check for duplicate invoice_id
SELECT invoice_id, COUNT(*) AS count
FROM invoice_line
GROUP BY invoice_id
HAVING COUNT(*) > 1;

-- Check for duplicate track_id
SELECT track_id, COUNT(*) AS count
FROM invoice_line
GROUP BY track_id
HAVING COUNT(*) > 1;

-- Check for duplicate unit_price
SELECT unit_price, COUNT(*) AS count
FROM invoice_line
GROUP BY unit_price
HAVING COUNT(*) > 1;

-- Check for duplicate quantity
SELECT quantity, COUNT(*) AS count
FROM invoice_line
GROUP BY quantity
HAVING COUNT(*) > 1;

-- Checking duplicates in media_type---
-- Check for duplicate media_type_id
SELECT media_type_id, COUNT(*) AS count
FROM media_type
GROUP BY media_type_id
HAVING COUNT(*) > 1;

-- Check for duplicate name
SELECT name, COUNT(*) AS count
FROM media_type
GROUP BY name
HAVING COUNT(*) > 1;

-- Checking duplicates in playlist---
-- Check for duplicate playlist_id
SELECT playlist_id, COUNT(*) AS count
FROM playlist
GROUP BY playlist_id
HAVING COUNT(*) > 1;

-- Check for duplicate name --
SELECT name, COUNT(*) AS count
FROM playlist
GROUP BY name
HAVING COUNT(*) > 1;

-- Checking duplicates in playlist_track---
-- Check for duplicate playlist_id
SELECT playlist_id, COUNT(*) AS count
FROM playlist_track
GROUP BY playlist_id;

-- Checking duplicates in track---
-- Check for duplicate name, album_id ----
SELECT name, album_id, COUNT(*)
 FROM track
GROUP BY name, album_id
HAVING COUNT(*) > 1;-- 

-- Check for duplicate album_id
SELECT album_id, COUNT(*) AS count
FROM track
GROUP BY album_id
HAVING COUNT(*) > 1;

-- Check for duplicate media_type_id
SELECT media_type_id, COUNT(*) AS count
FROM track
GROUP BY media_type_id
HAVING COUNT(*) > 1;

-- Check for duplicate genre_id
SELECT genre_id, COUNT(*) AS count
FROM track
GROUP BY genre_id
HAVING COUNT(*) > 1; -- 

-- Check for duplicate composer
SELECT composer, COUNT(*) AS count
FROM track
GROUP BY composer
HAVING COUNT(*) > 1;

-- Check for duplicate milliseconds
SELECT milliseconds, COUNT(*) AS count
FROM track
GROUP BY milliseconds
HAVING COUNT(*) > 1;

-- Check for duplicate bytes
SELECT bytes, COUNT(*) AS count
FROM track
GROUP BY bytes
HAVING COUNT(*) > 1;

-- Check for duplicate unit_price
SELECT unit_price, COUNT(*) AS count
FROM track
GROUP BY unit_price
HAVING COUNT(*) > 1;

-- Check for NULL values in Album --
SELECT * FROM Album WHERE album_id IS NULL;
SELECT * FROM Album WHERE title IS NULL;
SELECT * FROM Album WHERE artist_id IS NULL;

-- Check for NULL values in Artist --
SELECT * FROM Artist WHERE artist_id IS NULL;
SELECT * FROM Artist WHERE name IS NULL;

-- Check for NULL values in customer --
SELECT * FROM Customer WHERE first_name IS NULL;
SELECT * FROM Customer WHERE last_name IS NULL;
SELECT * FROM Customer WHERE company IS NULL;
SELECT * FROM Customer WHERE address IS NULL;
SELECT * FROM Customer WHERE city IS NULL;
SELECT * FROM Customer WHERE state IS NULL;
SELECT * FROM Customer WHERE country IS NULL;
SELECT * FROM Customer WHERE postal_code IS NULL;
SELECT * FROM Customer WHERE phone IS NULL;
SELECT * FROM Customer WHERE fax IS NULL;
SELECT * FROM Customer WHERE email IS NULL;
SELECT * FROM Customer WHERE support_rep_id IS NULL;

-- Check for NULL values in employee --
SELECT * FROM Employee WHERE employee_id IS NULL;
SELECT * FROM Employee WHERE last_name IS NULL;
SELECT * FROM Employee WHERE first_name IS NULL;
SELECT * FROM Employee WHERE title IS NULL;
SELECT * FROM Employee WHERE birthdate IS NULL;
SELECT * FROM Employee WHERE hire_date IS NULL;
SELECT * FROM Employee WHERE address IS NULL;
SELECT * FROM Employee WHERE city IS NULL;
SELECT * FROM Employee WHERE state IS NULL;
SELECT * FROM Employee WHERE country IS NULL;
SELECT * FROM Employee WHERE postal_code IS NULL;
SELECT * FROM Employee WHERE phone IS NULL;
SELECT * FROM Employee WHERE fax IS NULL;
SELECT * FROM Employee WHERE email IS NULL;

-- Check for NULL values in genre --
SELECT * FROM Genre WHERE genre_id IS NULL;
SELECT * FROM Genre WHERE name IS NULL;

-- Check for NULL values in invoice --
SELECT * FROM Invoice WHERE invoice_id IS NULL;
SELECT * FROM Invoice WHERE customer_id IS NULL;
SELECT * FROM Invoice WHERE invoice_date IS NULL;
SELECT * FROM Invoice WHERE billing_address IS NULL;
SELECT * FROM Invoice WHERE billing_city IS NULL;
SELECT * FROM Invoice WHERE billing_state IS NULL;
SELECT * FROM Invoice WHERE billing_country IS NULL;
SELECT * FROM Invoice WHERE billing_country IS NULL;
SELECT * FROM Invoice WHERE billing_postal_code IS NULL;
SELECT * FROM Invoice WHERE total IS NULL;

-- Check for NULL values in invoice_line--

SELECT * FROM invoice_line WHERE invoice_id IS NULL;
SELECT * FROM invoice_line WHERE track_id IS NULL;
SELECT * FROM invoice_line WHERE unit_price IS NULL;
SELECT * FROM invoice_line WHERE quantity IS NULL;

-- Check for NULL values in invoice_line--
    
SELECT * FROM media_type WHERE name IS NULL;

-- Check for NULL values in playlist--

SELECT * FROM playlist WHERE name IS NULL;

-- Check for NULL values in playlist--
SELECT * FROM Track WHERE track_id IS NULL;
SELECT * FROM Track WHERE name IS NULL;
SELECT * FROM Track WHERE album_id IS NULL;
SELECT * FROM Track WHERE media_type_id IS NULL;
SELECT * FROM Track WHERE genre_id IS NULL;
SELECT * FROM Track WHERE composer IS NULL;
SELECT * FROM Track WHERE milliseconds IS NULL;
SELECT * FROM Track WHERE bytes IS NULL;
SELECT * FROM Track WHERE unit_price IS NULL;

--- 2.Find the top-selling tracks & top artist in the USA and identify their most famous genres --

SELECT
  t.name AS Track_Name,
  ar.name AS Artist_Name,
  g.name AS Genre,
  SUM(il.quantity) AS Total_Quantity_Sold
FROM track t
JOIN album al ON t.album_id = al.album_id
JOIN artist ar ON al.artist_id = ar.artist_id
JOIN genre g ON t.genre_id = g.genre_id
JOIN invoice_line il ON t.track_id = il.track_id
JOIN invoice i ON il.invoice_id = i.invoice_id
JOIN customer c ON i.customer_id = c.customer_id
WHERE c.country = 'USA'
GROUP BY t.name, ar.name, g.name
ORDER BY Total_Quantity_Sold DESC
LIMIT 10;

 -- 3.What is the customer demographic breakdown (age, gender, location) of Chinook's customer base?
--- age & location  Breakdown----
  SELECT c.customer_id,c.first_name,c.last_name,
  TIMESTAMPDIFF(YEAR, e.birthdate, CURDATE()) AS age,c.city,c.state,c.country
FROM customer c
JOIN employee e ON c.support_rep_id = e.employee_id
limit 5;

-- 4. Calculate the total revenue and number of invoices for each country, state, and city? ---
---- Total Revenue by Country, State, and City:
SELECT billing_country, billing_state, billing_city, SUM(total) AS total_revenue
FROM invoice 
GROUP BY billing_country, billing_state, billing_city
ORDER BY total_revenue DESC limit 5;

----- Number of Invoices by Country, State, and City:  
  SELECT billing_country, billing_state, billing_city, COUNT(invoice_id) AS num_invoices
FROM invoice 
GROUP BY billing_country, billing_state, billing_city
ORDER BY num_invoices DESC LIMIT 5;


-- 5. Find the top 5 customers by total revenue in each country? -- 
SELECT c.country,c.customer_id,c.first_name,c.last_name,
SUM(i.total) AS total_revenue
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.country, c.customer_id
ORDER BY c.country, total_revenue DESC
LIMIT 5; 

-- 6.Identify the top-selling track for each customer 
WITH Cte AS (
    SELECT c.customer_id, c.first_name, c.last_name, t.track_id, t.name AS track_name,
           SUM(il.unit_price * il.quantity) AS total_revenue,
           ROW_NUMBER() OVER (PARTITION BY c.customer_id ORDER BY SUM(il.unit_price * il.quantity) DESC) AS revenue_rank
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    JOIN invoice_line il ON i.invoice_id = il.invoice_id
    JOIN track t ON il.track_id = t.track_id
    GROUP BY c.customer_id, c.first_name, c.last_name, t.track_id, t.name
)
SELECT customer_id, first_name, last_name, track_id, track_name, total_revenue
FROM Cte
WHERE revenue_rank = 1
ORDER BY customer_id;


-- 7.Are there any patterns or trends in customer purchasing behavior (e.g.frequency of purchases, preferred payment methods, average order value)  -- 
---- Frequency of Purchases
SELECT c.customer_id,c.first_name,c.last_name,
COUNT(i.invoice_id) AS purchase_frequency
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id
ORDER BY purchase_frequency DESC
limit 5;

--- Average Order Value --
SELECT c.customer_id,c.first_name,c.last_name,
Round(AVG(i.total)) AS average_order_value
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id
ORDER BY average_order_value DESC
limit 5;
 
 --- genre which was purchased on frequent basis --
SELECT g.name AS genre,COUNT(il.invoice_line_id) AS purchase_frequency
FROM genre g
JOIN track t ON g.genre_id = t.genre_id
JOIN invoice_line il ON t.track_id = il.track_id
JOIN invoice i ON il.invoice_id = i.invoice_id
GROUP BY g.name
ORDER BY purchase_frequency DESC
LIMIT 5;
    
--- 8.What is the customer churn rate?

--- Count Unique Customers in 2017:
SELECT COUNT(DISTINCT customer_id) AS customers_2017 
FROM invoice 
WHERE YEAR(invoice_date) = 2017;

---- Count Unique Customers in 2020:
SELECT COUNT(DISTINCT customer_id) AS customers_2020 
FROM invoice 
WHERE YEAR(invoice_date) = 2020;

--- number of customers who were active in 2017 but did not make any purchases in 2020
SELECT COUNT(DISTINCT customer_id) AS churned_customers 
FROM invoice 
WHERE YEAR(invoice_date) = 2017 
AND customer_id NOT IN (
    SELECT DISTINCT customer_id 
    FROM invoice 
    WHERE YEAR(invoice_date) = 2020
);

--  9.Calculate the percentage of total sales contributed by each genre in the USA and identify the best-selling genres and artists.
WITH GenreSales AS (
    SELECT g.name AS genre,
        SUM(il.unit_price * il.quantity) AS total_sales
    FROM Invoice i
    JOIN Invoice_Line il ON i.invoice_id = il.invoice_id
    JOIN Track t ON il.track_id = t.track_id
    JOIN Genre g ON t.genre_id = g.genre_id
    JOIN Customer c ON i.customer_id = c.customer_id
    WHERE c.country = 'USA'
    GROUP BY g.name
),
TotalSales AS (
    SELECT SUM(total_sales) AS total_sales_amount
    FROM GenreSales)
SELECT gs.genre,gs.total_sales,
   (gs.total_sales / ts.total_sales_amount * 100) AS sales_percentage
FROM GenreSales gs
CROSS JOIN TotalSales ts
ORDER BY gs.total_sales DESC
LIMIT 5;
    
--- 10.Find customers who have purchased tracks from at least 3 different genres
SELECT c.customer_id, c.first_name, c.last_name,
COUNT(DISTINCT g.genre_id) AS genre_count
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
JOIN invoice_line il ON i.invoice_id = il.invoice_id
JOIN track t ON il.track_id = t.track_id
JOIN genre g ON t.genre_id = g.genre_id
GROUP BY c.customer_id, c.first_name,c.last_name
HAVING genre_count >= 3;

-- ---- 11. Rank genres based on their sales performance in the USA
SELECT g.name AS genre,
RANK() OVER (ORDER BY SUM(il.unit_price * il.quantity) DESC) AS sales_rank
FROM genre g
JOIN track t ON g.genre_id = t.genre_id
JOIN invoice_line il ON t.track_id = il.track_id
JOIN invoice i ON il.invoice_id = i.invoice_id
GROUP BY g.name
ORDER BY sales_rank;
 
--- 12.Identify customers who have not made a purchase in the last 3 months
SELECT c.customer_id,c.first_name,c.last_name,
    MAX(i.invoice_date) AS last_purchase_date
FROM customer c
LEFT JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name
HAVING MAX(i.invoice_date) < DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
OR MAX(i.invoice_date) IS NULL;

-------------------------- SUBJECTIVE QUESTIONS --------------------------------------

-------- 1.	Recommend the three albums from the new 
---- record label that should be prioritised for advertising and promotion in the USA based on genre sales analysis.
SELECT 
    g.name AS Genre,
    SUM(il.unit_price * il.quantity) AS TotalSales
FROM 
    invoice_line il
    JOIN invoice i ON il.invoice_id = i.invoice_id
    JOIN track t ON il.track_id = t.track_id
    JOIN genre g ON t.genre_id = g.genre_id
WHERE 
    i.billing_country = 'USA'
GROUP BY 
    g.name
ORDER BY 
    TotalSales DESC
LIMIT 3;

--- 2. Determine the top-selling genres in countries other than the USA and identify any commonalities or differences.
WITH GenreSales AS (SELECT i.billing_country AS Country,g.name AS Genre,
        SUM(il.unit_price * il.quantity) AS TotalSales
    FROM invoice_line il
        JOIN invoice i ON il.invoice_id = i.invoice_id
        JOIN track t ON il.track_id = t.track_id
        JOIN genre g ON t.genre_id = g.genre_id
    WHERE i.billing_country != 'USA'
    GROUP BY i.billing_country, g.name),
TopGenres AS (SELECT Country,Genre,TotalSales,
	ROW_NUMBER() OVER (PARTITION BY Country ORDER BY TotalSales DESC) AS rn
    FROM GenreSales)
SELECT Country,Genre,TotalSales
FROM TopGenres
WHERE rn = 1
ORDER BY Country;

 
 
 ---- 3.Customer Purchasing Behavior Analysis: How do the purchasing habits (frequency, basket size, spending amount) of long-term customers differ from those of new customers?
 ----   What insights can these patterns provide about customer loyalty and retention strategies?
--- First Purchase Date for Each Customer
SELECT c.customer_id,MIN(i.invoice_date) AS first_purchase_date
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id;

--- Customers as Long-term
SELECT c.customer_id,
CASE WHEN MIN(i.invoice_date) < DATE_SUB(CURDATE(), INTERVAL 1 YEAR) THEN 'Long-term'ELSE 'New'
END AS customer_type
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id;

--- Purchasing Frequency
SELECT ct.customer_type,c.customer_id,COUNT(i.invoice_id) AS purchase_frequency
FROM (SELECT c.customer_id,
CASE WHEN MIN(i.invoice_date) < DATE_SUB(CURDATE(), INTERVAL 1 YEAR) THEN 'Long-term'ELSE 'New'
END AS customer_type
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id) ct
JOIN customer c ON ct.customer_id = c.customer_id
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY ct.customer_type, c.customer_id;

--- Basket Size
SELECT ct.customer_type,c.customer_id,ROUND(AVG(il.quantity)) AS average_basket_size
FROM (SELECT c.customer_id,
CASE WHEN MIN(i.invoice_date) < DATE_SUB(CURDATE(), INTERVAL 1 YEAR) THEN 'Long-term'ELSE 'New'
END AS customer_type
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id) ct
JOIN customer c ON ct.customer_id = c.customer_id
JOIN invoice i ON c.customer_id = i.customer_id
JOIN invoice_line il ON i.invoice_id = il.invoice_id
GROUP BY ct.customer_type, c.customer_id;

-- Spending Amount
SELECT ct.customer_type,c.customer_id,SUM(i.total) AS total_spending
FROM (SELECT c.customer_id,
CASE WHEN MIN(i.invoice_date) < DATE_SUB(CURDATE(), INTERVAL 1 YEAR) THEN 'Long-term'ELSE 'New'
END AS customer_type
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id) ct
JOIN customer c ON ct.customer_id = c.customer_id
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY ct.customer_type, c.customer_id;


---- 4. Product Affinity Analysis: Which music genres, artists, or albums are
---- frequently purchased together by customers? How can this information guide product recommendations and cross-selling initiatives?
-- Genre Pairs
SELECT g1.name AS genre1, g2.name AS genre2, COUNT(*) AS frequency
FROM invoice_line il1
JOIN track t1 ON il1.track_id = t1.track_id
JOIN genre g1 ON t1.genre_id = g1.genre_id
JOIN invoice_line il2 ON il1.invoice_id = il2.invoice_id
JOIN track t2 ON il2.track_id = t2.track_id
JOIN genre g2 ON t2.genre_id = g2.genre_id
WHERE il1.invoice_line_id < il2.invoice_line_id AND g1.name <> g2.name
GROUP BY g1.name, g2.name
ORDER BY frequency DESC
LIMIT 10;

--- Artist Pairs
SELECT a1.name AS artist1, a2.name AS artist2, COUNT(*) AS frequency
FROM invoice_line il1
JOIN track t1 ON il1.track_id = t1.track_id
JOIN album al1 ON t1.album_id = al1.album_id
JOIN artist a1 ON al1.artist_id = a1.artist_id
JOIN invoice_line il2 ON il1.invoice_id = il2.invoice_id
JOIN track t2 ON il2.track_id = t2.track_id
JOIN album al2 ON t2.album_id = al2.album_id
JOIN artist a2 ON al2.artist_id = a2.artist_id
WHERE il1.invoice_line_id < il2.invoice_line_id AND a1.name <> a2.name
GROUP BY a1.name, a2.name
ORDER BY frequency DESC
LIMIT 10;

--- Album pair
SELECT al1.title AS album1, al2.title AS album2, COUNT(*) AS frequency
FROM invoice_line il1
JOIN track t1 ON il1.track_id = t1.track_id
JOIN album al1 ON t1.album_id = al1.album_id
JOIN invoice_line il2 ON il1.invoice_id = il2.invoice_id
JOIN track t2 ON il2.track_id = t2.track_id
JOIN album al2 ON t2.album_id = al2.album_id
WHERE il1.invoice_line_id < il2.invoice_line_id
AND al1.title <> al2.title
GROUP BY al1.title, al2.title
ORDER BY frequency DESC
LIMIT 10;

 
 ---- 5.Regional Market Analysis: Do customer purchasing behaviors and churn rates vary 
----- across different geographic regions or store locations? How might these correlate with local demographic or economic factors?

--- Purchasing Behaviors
SELECT c.country, c.city, COUNT(DISTINCT i.invoice_id) AS total_purchases,
SUM(il.unit_price * il.quantity) AS total_spending,
(Round(AVG(il.unit_price * il.quantity))) AS avg_spending_per_purchase,
COUNT(DISTINCT c.customer_id) AS total_customers
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
JOIN invoice_line il ON i.invoice_id = il.invoice_id
GROUP BY c.country, c.city
ORDER BY total_spending DESC
LIMIT 5;

WITH customer_last_purchase AS (
    SELECT c.customer_id,MAX(i.invoice_date) AS last_purchase_date,c.country,c.city
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY c.customer_id, c.country, c.city
)
SELECT country,city,COUNT(*) AS total_customers,
SUM(CASE WHEN DATEDIFF(CURDATE(), last_purchase_date) > 365 THEN 1 ELSE 0 END) AS churned_customers,
(SUM(CASE WHEN DATEDIFF(CURDATE(), last_purchase_date) > 365 THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS churn_rate
FROM customer_last_purchase
GROUP BY country, city
ORDER BY churn_rate DESC
limit 5;


---- 6.Customer Risk Profiling: Based on customer profiles (age, gender, location, purchase history), 
---- which customer segments are more likely to churn or pose a higher risk of reduced spending? What factors contribute to this risk?

---- Customers with No Recent Purchases (Potential Churn)
SELECT c.customer_id, c.first_name, c.last_name, c.country, MAX(i.invoice_date) AS last_purchase_date
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name, c.country
HAVING MAX(i.invoice_date) < DATE_SUB(CURDATE(), INTERVAL 1 YEAR);

--- Customers by Spending Patterns
SELECT c.customer_id, c.first_name, c.last_name, c.country,
       COUNT(i.invoice_id) AS purchase_count, 
       SUM(i.total) AS total_spent, 
       AVG(i.total) AS avg_spent_per_purchase,
       MAX(i.invoice_date) AS last_purchase_date
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name, c.country
ORDER BY total_spent DESC
LIMIT 5;

--- Customer Segments by Location
SELECT c.country,
       COUNT(c.customer_id) AS total_customers,
       COUNT(i.invoice_id) AS total_purchases,
       SUM(i.total) AS total_revenue,
       AVG(i.total) AS avg_revenue_per_purchase,
       MAX(i.invoice_date) AS last_purchase_date
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.country
ORDER BY total_revenue DESC
LIMIT 5;

---- Purchase Frequency and Recency
SELECT c.customer_id, c.first_name, c.last_name, c.country,
       COUNT(i.invoice_id) AS purchase_count, 
       DATEDIFF(CURDATE(), MAX(i.invoice_date)) AS days_since_last_purchase,
       CASE
           WHEN DATEDIFF(CURDATE(), MAX(i.invoice_date)) > 365 THEN 'High Risk'
           WHEN DATEDIFF(CURDATE(), MAX(i.invoice_date)) BETWEEN 180 AND 365 THEN 'Medium Risk'
           ELSE 'Low Risk'
       END AS risk_profile
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name, c.country
Limit 5;
 
 ----- 7.Customer Lifetime Value Modeling: How can you leverage customer data (tenure, purchase history, engagement)
 ---- to predict the lifetime value of different customer segments? This could inform targeted marketing and
 ---- loyalty program strategies. Can you observe any common characteristics or purchase patterns among customers who have stopped purchasing?

-- Extract customer tenure (duration since first purchase)
SELECT c.customer_id, c.first_name, c.last_name, c.country, MIN(i.invoice_date) AS first_purchase_date, MAX(i.invoice_date) AS last_purchase_date, COUNT(i.invoice_id) AS purchase_count, SUM(i.total) AS total_spent
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id;

--- Extract purchase details
SELECT i.customer_id, il.invoice_line_id, il.track_id, il.unit_price, il.quantity, t.album_id, t.genre_id
FROM invoice_line il
JOIN invoice i ON il.invoice_id = i.invoice_id
JOIN track t ON il.track_id = t.track_id;
 
 -- Extract album and artist details
SELECT t.track_id, a.album_id, ar.artist_id, ar.name AS artist_name
FROM track t
JOIN album a ON t.album_id = a.album_id
JOIN artist ar ON a.artist_id = ar.artist_id;

----------------   8. If data on promotional campaigns (discounts, events, email marketing) is available, how could you measure their 
------------ impact on customer acquisition, retention, and overall sales?

-- New customers acquired during the promotional period
SELECT MIN(i.invoice_date) AS first_purchase_date,
COUNT(DISTINCT i.customer_id) AS new_customers
FROM invoice i
JOIN customer c ON i.customer_id = c.customer_id
WHERE i.invoice_date BETWEEN '2018-01-01' AND '2018-01-31'
GROUP BY i.customer_id
HAVING first_purchase_date BETWEEN '2018-01-01' AND '2018-01-31';
 
 -- Repeat purchases by customers who made a purchase during the promotional period
 SELECT COUNT(DISTINCT i2.invoice_id) AS repeat_purchases,COUNT(DISTINCT i1.customer_id) AS total_customers
FROM invoice i1
JOIN invoice i2 ON i1.customer_id = i2.customer_id
WHERE i1.invoice_date BETWEEN '2018-01-01' AND '2018-01-31'AND i2.invoice_date > '2018-01-31';   

-- Sales before, during, and after the promotional period
SELECT SUM(CASE WHEN i.invoice_date BETWEEN '2017-12-01' AND '2017-12-31' THEN i.total ELSE 0 END) AS before_campaign_sales,
SUM(CASE WHEN i.invoice_date BETWEEN '2018-01-01' AND '2018-01-31' THEN i.total ELSE 0 END) AS during_campaign_sales,
SUM(CASE WHEN i.invoice_date BETWEEN '2020-02-01' AND '2020-02-28' THEN i.total ELSE 0 END) AS after_campaign_sales
FROM invoice i;
 
 
-- 9. How would you approach this problem, if the objective and subjective questions weren't given? 
-- Analyze Customer Acquisition (Customers who made their first purchase during the campaign period)
SELECT COUNT(DISTINCT customer_id) AS new_customers
FROM invoice
WHERE invoice_date BETWEEN '2018-01-01' AND '2018-01-31'
AND customer_id NOT IN (SELECT customer_id FROM invoice
WHERE invoice_date < '2018-01-01'
    );

--  Analyze Customer Retention (Measure Repeat Purchases)
SELECT COUNT(DISTINCT i1.customer_id) AS retained_customers
FROM invoice i1
JOIN invoice i2 ON i1.customer_id = i2.customer_id
WHERE i1.invoice_date < '2018-01-01'
AND i2.invoice_date BETWEEN '2018-01-01' AND '2018-01-31';

-- Overall Sales Comparison(To compare the total sales before, during, and after the campaign period)
SELECT 
    SUM(CASE WHEN invoice_date BETWEEN '2017-12-01' AND '2017-12-31' THEN total ELSE 0 END) AS sales_before,
    SUM(CASE WHEN invoice_date BETWEEN '2018-01-01' AND '2018-01-31' THEN total ELSE 0 END) AS sales_during_campaign,
    SUM(CASE WHEN invoice_date BETWEEN '2018-02-01' AND '2018-02-28' THEN total ELSE 0 END) AS sales_after
FROM invoice;

-- 10.How can you alter the "Albums" table to add a new column named "ReleaseYear" of type INTEGER to store the release year 
---- of each album?
ALTER TABLE album
ADD COLUMN ReleaseYear INTEGER;
select * from album;

-- 11,Chinook is interested in understanding the purchasing behavior of customers based on their geographical location. 
-- They want to know the average total amount spent by customers from each country, along with the number of customers 
-- and the average number of tracks purchased per customer. Write an SQL query to provide this information.

WITH customer_spending AS (
    SELECT c.customer_id, c.country, SUM(i.total) AS total_spent, COUNT(il.track_id) AS total_tracks
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    JOIN invoice_line il ON i.invoice_id = il.invoice_id
    GROUP BY c.customer_id, c.country
),country_summary AS (
    SELECT country, COUNT(customer_id) AS number_of_customers,
           ROUND(AVG(total_spent))AS avg_total_spent,
           ROUND(AVG(total_tracks)) AS avg_tracks_per_customer
    FROM customer_spending
    GROUP BY country
)SELECT country, number_of_customers, avg_total_spent, avg_tracks_per_customer
FROM country_summary
ORDER BY country;
